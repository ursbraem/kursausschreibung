window.kursausschreibung = window.kursausschreibung || {};
window.kursausschreibung.appConfig = {
  // the token type
  "tokenType": "urn:ietf:params:oauth:token-type:jwt-bearer",
  // API base URL without trailing slash
  "apiUrl": "https://eventotest.api",
  // base Url of the web application without trailing slash (also the redirect url for public clients)
  "webBaseUrl": "https://test.com",
  // base url of the CLX.Evento OAuth Server.
  "oauthUrl": "https://eventotest.oauth",
  // the instance id for this application.
  "instanceId": "testInstanz",
  // the client id for this application.
  "clientId": "testClientId",
  // set this to true if you want to use autologin on your page. If "false" the authorization must be done by the application, that module does not perform authorization. If false and no token found in the local storage (CLX.LoginToken) the "kursausschreibung" application only refresh the actual url. The application must be redirect user to login form.
  "useAutoLogin": true,
  // the scope of the application
  "applicationScope": "Public"
};
